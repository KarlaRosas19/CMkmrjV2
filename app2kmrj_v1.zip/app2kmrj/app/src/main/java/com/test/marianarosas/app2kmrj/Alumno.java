package com.test.marianarosas.app2kmrj;

public class Alumno {

    String Nombre;
    String Apellidos;
    String Cuenta;
    String Genero;

    public Alumno(String Nombre, String Apellidos, String Cuenta, String Genero ){


        this.Nombre=Nombre;
        this.Apellidos=Apellidos;
        this.Cuenta=Cuenta;
        this.Genero=Genero;
    }

    public String getAlumno(){

        return (" "+Nombre +" "+ Apellidos +" "+ Cuenta+ " "+Genero);
    }

    public void setAlumno(String Nombre, String Apellidos, String Cuenta, String Genero ) {
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Cuenta=Cuenta;
        this.Genero=Genero;
    }
/*
    public String getNombre(String Nombre){
       return Nombre;
    }
    public String getApellidos(String Apellidos){
        return Apellidos;
    }
    public void setNombre(String Nombre){
        this.Nombre=Nombre;
    }
    public void setApellidos(String Apellidos){
        this.Nombre=Apellidos;
    }
 */
 }
