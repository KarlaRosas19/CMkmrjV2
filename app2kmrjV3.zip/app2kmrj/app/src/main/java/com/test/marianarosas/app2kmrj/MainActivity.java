package com.test.marianarosas.app2kmrj;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    //Definicion de variables
    private EditText editext;
    private EditText editext2;
    private Button ba1;
    private ListView list;
    private ArrayAdapter<String> adapter;
    private ArrayList arrayList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editext=(EditText)findViewById(R.id.et1);
        editext=(EditText)findViewById(R.id.et2);
        ba1=(Button)findViewById(R.id.ba1);
        list = (ListView)findViewById(R.id.listview);
        arrayList=new ArrayList<String>();

        final Alumno al=new Alumno("","","","");

        al.setAlumno("Karla Mariana","Rosas Michaud","312221755","F");


        adapter= new ArrayAdapter<String>(getApplicationContext(),R.layout.custum,arrayList);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String listaAlumnos = (String)list.getItemAtPosition(position);
                Toast.makeText(getApplication(),"ID"+(position+1),Toast.LENGTH_SHORT).show();

            }
        });

        ba1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //arrayList.add(editext.getText().toString());
                arrayList.add(al.getAlumno());

                adapter.notifyDataSetChanged(); //Actualizar los cambios
            }
        });


    }

    //Boton Ver -Para ver la lista
    public void Siguiente(View view){
        Intent siguiente =new Intent(this, Main2Activity.class);
        startActivity(siguiente);
    }

}
