package com.test.marianarosas.app2kmrj;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {


    private ListView list2;
    private ArrayAdapter<String> adapter2;
    private ArrayList arrayList2;
    private Button bagregar2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        list2 = (ListView)findViewById(R.id.listview2);
        arrayList2=new ArrayList<String>();
        bagregar2=(Button)findViewById(R.id.bagregar2);

        final Alumno al=new Alumno("","","","");

        al.setAlumno("Karla Mariana","Rosas Michaud","312221755","F");

        adapter2= new ArrayAdapter<String>(getApplicationContext(),R.layout.custum,arrayList2);
        list2.setAdapter(adapter2);

        list2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String listaAlumnos = (String)list2.getItemAtPosition(position);
                Toast.makeText(getApplication(),"ID"+(position+1),Toast.LENGTH_SHORT).show();

            }
        });

        bagregar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                arrayList2.add(al.getAlumno());
                adapter2.notifyDataSetChanged();
            }
        });
/*
        bagregar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //arrayList.add(editext.getText().toString());
                arrayList2.add(al.getAlumno());

                adapter2.notifyDataSetChanged(); //Actualizar los cambios
            }
        });*/

    }

    //METODOS

    //Metodo para el boton "Regresar"
    public void Regresar(View view){
        Intent regresar = new Intent(this, MainActivity.class);
        startActivity(regresar);
    }
}
